# 本目录下文件 规则例子

## 规则编写的参考文档

1. [图片镜像缓存服务—防盗链图片、imgur 等国内无法访问图片的解决方案](https://funletu.com/10538/.html)

```text
# 使用

https://github.com/justjavac/ReplaceGoogleCDN/blob/master/experimental-features/v3/rules/example/imgur.com-stackoverflow.com.json?raw=true

```
