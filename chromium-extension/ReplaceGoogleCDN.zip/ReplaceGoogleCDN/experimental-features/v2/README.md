# v2 版本试验特性

## [WebExtensions incognito](https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/manifest.json/incognito)

## 发现 v2 版本功能齐全,具有 WebUI 的的扩展 [HeaderEditor](https://github.com/FirefoxBar/HeaderEditor.git)
