# CHANGELOG for v2

## CHANGELOG for v2 0.10.17 [2023-12-05 00:49:00 +0800]

> 1. 格式化代码

## CHANGELOG for v2 0.10.16 [2023-02-09 13:01:00 +0800]

> 1. v2 版本 修改 高级用法分离出去,精简默认代码
> 1. v2 版本 升级 到 0.10.16

## CHANGELOG for v2 0.10.15 [2023-02-06 23:49:00 +0800]

> 1. v2 版本 修改 `fonts.gstatic.com` 和 `fonts.gstatic.com` 重定向地址
> 1. v2 版本 新增 `developer.android.com` 地址重定向
> 1. v2 版本 新增 `source.android.com` 地址重定向
> 1. v2 版本 升级 到 0.10.15
