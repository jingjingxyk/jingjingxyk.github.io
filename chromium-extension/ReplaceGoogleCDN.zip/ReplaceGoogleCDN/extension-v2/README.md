# 启用同时支持 chromium 和 firefox

## [WebExtensions incognito](https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/manifest.json/incognito)

## 高级玩法测试例子

- https://gerrit.googlesource.com/gerrit
- https://www.chromium.org
- https://chromium.googlesource.com/
- https://source.chromium.org/chromium
- https://cs.opensource.google/
