# 启用同时支持 chromium 和 firefox

## 发现 v2 版本功能齐全,具有 WebUI 的的扩展 [HeaderEditor](https://github.com/FirefoxBar/HeaderEditor.git)

## v2 版本扩展支持 chromium 内核版本 49

## v2 版本 与 v3 最大的区别：

> V3 版本不允许通过 javascript 脚本 动态 http 的修改请求头和响应头

## [WebExtensions incognito](https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/manifest.json/incognito)
