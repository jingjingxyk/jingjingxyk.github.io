# 启用同时支持 chromium 和 firefox

## [WebExtensions incognito](https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/manifest.json/incognito)

## 高级玩法测试例子

- https://gerrit.googlesource.com/gerrit
- https://www.chromium.org
- https://chromium.googlesource.com/
- https://source.chromium.org/chromium
- https://cs.opensource.google/

## 发现 v2 版本功能齐全的扩展[HeaderEditor](https://github.com/FirefoxBar/HeaderEditor.git)

> HeaderEditor 没有提供 v3 版本。但是它的界面很好用

## 本扩展的 v2 版本支持 chromium 内核版本 49
