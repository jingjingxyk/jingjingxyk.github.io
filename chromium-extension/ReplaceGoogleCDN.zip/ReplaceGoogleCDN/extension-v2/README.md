# ReplaceGoogleCDN

> v2版本同时支持 chromium 和 firefox

> v2 版本扩展支持 chromium 最小内核版本是 49

## V2 为什么要升级到 V3

> Chrome 网上应用店将不再接受新的 Manifest V2 扩展。 开发者仍可推送现有 Manifest V2 扩展的更新

> Manifest version 2 is deprecated, and support will be removed in 2023.
> See [mv2-transition](https://developer.chrome.com/blog/mv2-transition/) for more details.
