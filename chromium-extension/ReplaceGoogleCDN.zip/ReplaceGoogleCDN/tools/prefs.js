user_pref("devtools.chrome.enabled", true);
user_pref("devtools.debugger.remote-enabled", true);
user_pref("devtools.debugger.prompt-connection", false);
user_pref("fission.bfcacheInParent", false);
user_pref("fission.webContentIsolationStrategy", 0);
user_pref("xpinstall.signatures.required", false);
user_pref("xtensions.langpacks.signatures.required", false);
