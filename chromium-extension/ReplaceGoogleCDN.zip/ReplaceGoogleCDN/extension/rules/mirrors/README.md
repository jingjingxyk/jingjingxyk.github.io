# 公共可用候选资源

> 多个规则候选项，优先级高的规则生效

## 静态默认规则候选项载入地址

```text

https://github.com/justjavac/ReplaceGoogleCDN/blob/master/extension/rules/mirrors/ajax.googleapis.com.json?raw=true
https://github.com/justjavac/ReplaceGoogleCDN/blob/master/extension/rules/mirrors/fonts.googleapis.com.json?raw=true
https://github.com/justjavac/ReplaceGoogleCDN/blob/master/extension/rules/mirrors/gravatar.com.json?raw=true
https://github.com/justjavac/ReplaceGoogleCDN/blob/master/extension/rules/mirrors/cdnjs.cloudflare.com.json?raw=true
https://github.com/justjavac/ReplaceGoogleCDN/blob/master/extension/rules/mirrors/fonts.gstatic.com.json?raw=true
https://github.com/justjavac/ReplaceGoogleCDN/blob/master/extension/rules/mirrors/themes.googleusercontent.com.json?raw=true

```
