## 工具集

## mainifest v3 兼容 firefox 工具

```shell
# 查看帮助
python3 extension/tools/update-manifest.py  --help

# 切换mainfest.json 支持 chromium 系浏览器
python3 extension/tools/update-manifest.py  chromium

# 切换mainfest.json 支持 firefix  系浏览器
python3 extension/tools/update-manifest.py  firefox

```
