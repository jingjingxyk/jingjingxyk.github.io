import indexController from "../Controller/indexController.js";
export default () => {
  indexController();
};
