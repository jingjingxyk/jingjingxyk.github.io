import advanceController from "../Controller/advanceController.js";

export default () => {
  advanceController();
};
