# 测试用例

> 打开 dev-tools 面板查看请求

1. [stackoverflow 打开 `https://stackoverflow.com/tags/socat/hot?filter=all` 查看结果](https://stackoverflow.com/tags/socat/hot?filter=all)
1. [Google reCAPTCHA 打开 `https://patrickhlauke.github.io/recaptcha/` 查看结果](https://patrickhlauke.github.io/recaptcha/)
1. [ `pub.dev` 域名下 `fonts.googleapis.com` 无法地址重定向； 打开 `https://pub.dev/` 查看结果](https://pub.dev/)
1. [`cdn.jsdelivr.net` 替换为 `fastly.jsdelivr.net` 打开 `https://cdn.jsdelivr.net/` 查看结果 ](https://cdn.jsdelivr.net/npm/jquery@3/dist/jquery.min.js)
1. [`cdnjs.cloudflare.com` 替换为 `cdnjs.loli.net` 打开 `https://cdnjs.cloudflare.com/` 查看结果 ](https://cdnjs.cloudflare.com/ajax/libs/reveal.js/4.1.2/reveal.min.css)
1. [`developers.google.com` 替换为 `developers.google.cn` 打开 `https://developers.google.com/` 查看结果 ](https://developers.google.com)
1. [`code.jquery.com/jquery-` 替换为 `lib.baomitu.com/jquery/` 打开 `https://releases.jquery.com/` 查看结果 ](https://releases.jquery.com/)
1. [`code.jquery.com/ui/` 替换为 `ajax.aspnetcdn.com/ajax/jquery.ui` 打开 `https://releases.jquery.com/` 查看结果 ](https://releases.jquery.com/)
1. [`commondatastorage.googleapis.com/chromium-browser-snapshots/` 替换为 `https://registry.npmmirror.com/-/binary/chromium-browser-snapshots//Mac/1086244/chrome-mac.zip` 打开 `https://commondatastorage.googleapis.com/chromium-browser-snapshots/` 查看结果 ](https://commondatastorage.googleapis.com/chromium-browser-snapshots/Mac/1086244/chrome-mac.zip)
1. [developer.android.com](https://developer.android.com/?hl=zh-cn)
1. [source.android.com](https://source.android.com)
1. [jquery](https://releases.jquery.com/)
1. [material](https://m3.material.io/)
