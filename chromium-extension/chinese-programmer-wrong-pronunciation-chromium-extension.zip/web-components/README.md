# HTML Imports，HTML Template、Shadow DOM----统称为 Web Components 规范

## Shadow DOM 实现代码隔离
