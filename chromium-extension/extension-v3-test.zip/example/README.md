# 通过窗口大小，修改User-Agent
