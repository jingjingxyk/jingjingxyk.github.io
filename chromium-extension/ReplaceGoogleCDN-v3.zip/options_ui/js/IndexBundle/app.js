import indexRouter from "./Router/indexRouter.js";

export default () => {
  indexRouter();
};
