import * as THREE from  'https://cdnjs.cloudflare.com/ajax/libs/three.js/0.146.0/three.module.min.js'
import * as  utils from 'https://www.jingjingxyk.com/ajax/libs/jingjingxyk/frontend-utils/utils.js'

import { JSONEditor } from "https://www.jingjingxyk.com/ajax/libs/josdejong/svelte-jsoneditor/main/index.js";


const scene = new THREE.Scene();
console.log(utils )
console.log(utils.default )
