# reference
1. [98wubi-tables](https://github.com/jingjingxyk/98wubi-tables.git)
2. [emoji unicode.org]( https://unicode.org/emoji/charts/index.html)
3. [千千秀字](https://www.qqxiuzi.cn/)
