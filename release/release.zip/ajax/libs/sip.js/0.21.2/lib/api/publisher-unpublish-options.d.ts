/**
 * Options for {@link Publisher.unpublish}.
 * @public
 */
export interface PublisherUnpublishOptions {
}
