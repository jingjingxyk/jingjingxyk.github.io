/**
 * Options for {@link Publisher.publish}.
 * @public
 */
export interface PublisherPublishOptions {
}
