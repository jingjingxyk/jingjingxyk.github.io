/**
 * TODO: This is currently just a placeholder.
 * Notifier is the peer of a Subscriber.
 * That is, a Notifier sends NOTIFY requests.
 * @internal
 */
export declare class Notifier {
}
