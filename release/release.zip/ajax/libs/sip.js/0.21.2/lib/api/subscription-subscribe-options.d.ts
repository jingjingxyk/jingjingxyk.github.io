/**
 * Options for {@link Subscription.subscribe}.
 * @public
 */
export interface SubscriptionSubscribeOptions {
}
