/**
 * Timers.
 * @public
 */
export declare const Timers: {
    T1: number;
    T2: number;
    T4: number;
    TIMER_B: number;
    TIMER_D: number;
    TIMER_F: number;
    TIMER_H: number;
    TIMER_I: number;
    TIMER_J: number;
    TIMER_K: number;
    TIMER_L: number;
    TIMER_M: number;
    TIMER_N: number;
    PROVISIONAL_RESPONSE_INTERVAL: number;
};
